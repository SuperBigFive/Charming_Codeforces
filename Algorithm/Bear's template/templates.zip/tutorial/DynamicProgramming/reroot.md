$$
dpE(u,v)=\bigoplus_{(v,w) \in E, w \neq u} T(dpE(v, w), w(u,v)) \oplus f(u) \\
dpV(u)=\bigoplus_{(u,v) \in E} dpE(u, v)\\
dpV^*(u)=\bigoplus_{(u,v) \in E, v \neq f} dpE(u,v) = dpE(f, u)\\
$$

