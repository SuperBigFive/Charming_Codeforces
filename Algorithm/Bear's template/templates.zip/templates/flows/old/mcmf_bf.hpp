#include <bits/stdc++.h>
using namespace std;

int main(void) {
    

    return 0;
}