#include "bis.hpp"

int main(void) {
    bis b1, b2;
    cin >> b1 >> b2;
    cout << b1 * b2 << endl;
    return 0;
}