$$
(u+v \sqrt d)^p=\sum_{i=0}^p\binom pi u^i(v\sqrt d)^{p-i}=u^p+v^p\sqrt d(d)^{(p-1)/2}=u-v\sqrt d\\
$$

因此$\mathbb F[\sqrt d]$的乘法群是一个$p^2-1$阶循环群。

