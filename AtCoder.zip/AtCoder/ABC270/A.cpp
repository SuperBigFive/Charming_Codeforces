#include <bits/stdc++.h>
#define ll long long
#define int ll
using namespace std;
const int maxn = 2e6 + 5;

void init () {}

void charming () {
	int a, b;
	cin >> a >> b;
	cout << (a | b) << endl;
}

signed main () {
	charming ();
	return 0;
}