s = input (); print (s.upper ())
