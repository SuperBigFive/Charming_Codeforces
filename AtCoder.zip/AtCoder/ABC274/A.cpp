#include <bits/stdc++.h>
#define ll long long
#define int ll
using namespace std;
const int maxn = 2e5 + 5;

void init () {}

void charming () {
	double a, b;
	cin >> a >> b;
	printf ("%.3lf", b / a);
}

signed main () {
	charming ();
	return 0;
}