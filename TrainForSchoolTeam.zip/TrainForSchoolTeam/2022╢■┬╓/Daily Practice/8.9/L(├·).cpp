#include <bits/stdc++.h>
#define ll long long
#define int ll
#define vi vector <int> 
#define pii pair <int, int> 
#define pip pait <int, pii>
#define pb push_back 
#define fi first
#define se second
#define inl inline
#define rg register int
using namespace std;
const int maxn = 2e5 + 5;

ll n;

void init () {
}

void charming () {
	init ();
	cin >> n;
	cout << (n - 1) / 2 + 1 << endl;
}

signed main () {
	charming ();
	return 0;
}