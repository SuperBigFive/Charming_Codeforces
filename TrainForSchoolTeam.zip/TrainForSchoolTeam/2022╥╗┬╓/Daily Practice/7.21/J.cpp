#include <bits/stdc++.h>
#define ll long long
#define int ll
#define vi vector <int>
#define pii pair <int, int>
#define ppii pair <int, pii >
#define pb push_back
#define fir first
#define se second
using namespace std;
const int maxn = 2e5 + 5;

int t;
ll l, r;

void init () {
	
}

void charming () {
	cin >> l >> r;
	cout << l << ' ' << 2 *  l << endl;
}

signed main () {
	cin >> t;
	while (t--) charming ();
	return 0;
}