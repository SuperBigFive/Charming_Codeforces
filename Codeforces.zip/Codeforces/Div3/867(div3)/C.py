for i in range (int (input ())) :
  n = int (input ())
  print (n * (n + 2) + 2)
