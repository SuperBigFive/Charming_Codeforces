#include <bits/stdc++.h>
using namespace std;

int t, n;

void charming () {
	cin >> n;
	cout << (n + 1) / 2 << endl;
}

signed main () {
	cin >> t;
	while (t--) charming ();
	return 0;
}