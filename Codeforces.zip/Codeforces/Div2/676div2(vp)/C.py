s = input (); n = len (s)
print (3); print ("L", 2); print ("R", 2); print ("R", 2 * n - 1)
